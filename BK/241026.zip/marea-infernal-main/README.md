# Marea Infernal

Juego de acción y supervivencia en arenas, visto desde arriba y hecho con HTML,
CSS y JavaScript. Elige un arma, sobrevive a oleadas interminables de demonios,
mejora tu equipo con cenizas y derrota al Señor de la Marea.

## Jugar

Abre `index.html` en un navegador moderno. No requiere instalación de
dependencias ni servidor web.

## Cómo se juega

- **Sobrevive:** no hay temporizador ni límite de oleadas. La partida termina
  cuando la vida del personaje llega a cero.
- **Elige tu clase antes de jugar:** el Arquero combate a distancia con flechas; el
  Mago lanza orbes y un meteorito de área; el Bárbaro golpea de cerca con tajos,
  lanza hachas giratorias y usa ataques de área visibles. La clase queda fija durante esa partida.
  El Mago no tiene crítico: su stat de arma es **Poder** (+0,5 % por punto), que agranda el
  radio del Meteorito y suma un orbe a la Salva arcana cada 10 % (hasta formar un círculo completo).
- **Lee las zonas de impacto:** el meteorito marca el área antes de caer y la
  muestra al impactar. El hacha dibuja el arco frontal del tajo y el radio de
  su golpe sísmico.
- **Ataca automáticamente:** cada arma tiene tres ataques —básico, intermedio y
  definitivo— que se activan solos cuando hay enemigos cerca y termina su
  cooldown. Apunta con el ratón para orientar proyectiles y ataques frontales.
- **Muévete:** desplázate por la arena para esquivar peligros y posicionarte.
- **Esquiva:** usa el dash para desplazarte rápidamente y evitar daño. Tiene
  tiempo de recarga e incluye un breve periodo de invulnerabilidad.
- **Sube de nivel:** recoge la experiencia que dejan los enemigos. Cada nivel
  aumenta tus atributos y restaura toda tu vida.
- **Reúne cenizas:** los enemigos pueden dejar cenizas. También recibes una
  recompensa al superar oleadas y al derrotar jefes.
- **Mejora el equipo:** abre el inventario durante la partida para gastar
  cenizas en las seis piezas iniciales —arma, casco, pecho, guantes, botas y
  anillo—. Cada pieza tiene atributos mejorables; al llegar a +10 puedes subir
  su rareza y continuar mejorándola.
- **Abre cofres:** acércate y pulsa `E` antes de que desaparezcan. Pueden
  aparecer durante las tandas de enemigos y siempre aparecen al derrotar al
  jefe. En los intermedios hay un cofre de bonificación: ábrelo con `E` o
  continúa para recibir la recompensa automáticamente.
- **Prepárate para los jefes:** el Señor de la Marea aparece cada 10 oleadas.
  A partir de las oleadas avanzadas suma nuevos ataques: salto desde la oleada
  20 y lluvia de fuego desde la 30.
- **Descansa entre ciclos:** cada cinco oleadas, elimina a todos los enemigos
  para entrar en un intermedio. No aparecerán nuevos enemigos hasta que pulses
  **Continuar**; puedes revisar el inventario y reclamar el cofre de
  bonificación antes de seguir.
- **Observa los escenarios:** el entorno cambia cada 10 oleadas.

## Controles

| Acción | Control |
| --- | --- |
| Moverse | `W`, `A`, `S`, `D` o flechas |
| Apuntar y orientar ataques | Mover el ratón |
| Ataques del arma | Automáticos, con cooldown |
| Esquivar (dash) | `Espacio` |
| Abrir un cofre cercano | `E` |
| Abrir o cerrar el inventario | `I` |
| Pausar o volver desde una pausa | `Esc` |

Los ataques se activan de forma escalonada para no disparar todas las
habilidades a la vez. El inventario también pausa la acción para que puedas
hacer mejoras.

## Puntuaciones

Al terminar una partida puedes guardar el resultado con un nombre. La tabla de
puntuaciones y el récord se almacenan localmente en el navegador (`localStorage`);
no se sincronizan entre dispositivos o navegadores.

## Archivos del proyecto

- `index.html`: estructura del juego y orden de carga de scripts.
- `css/estilos.css`: estilos, HUD, menús y overlays.
- `js/mecanica.js`: estado, oleadas, combate, inventario y puntuaciones.
- `js/personajes.js`: movimiento, disparo, habilidades y progresión del jugador.
- `js/enemigos.js`: enemigos, cofres, jefes y renderizado asociado.
